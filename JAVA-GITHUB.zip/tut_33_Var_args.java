package com.company;

public class tut_33_Var_args {
     
    static  int sum(int...arr) {
        // Available as  int []arr
        int sum=0;
        for (int a:arr){
            sum=sum+a;
        }
        return sum;
    }

    public static void main(String[] args) {
        System.out.println("the sum of 2,3,5    ="+sum(2,3,5));
        System.out.println("the sum of 2,3,5+3  ="+sum(2,3,5,3));
        System.out.println("the sum of 2,3,5,7,8  ="+sum(2,3,5,7,8));
        System.out.println("the sum of 2,3,5,1,2,3,4,5,6,7   ="+sum(2,3,5,1,2,3,4,5,6,7));
        System.out.println("the sum of 2,3,5,8,8,8,6   ="+sum(2,3,5,8,8,8,6));
    }
}
