package com.company;

import java.util.Scanner;

public class tut_19_chap4_ques5 {
    public static void main(String[] args) {
        Scanner sc= new  Scanner(System.in);
        System.out.println("enter the website name to find the type of the website ");
        String website=sc.next();
        if(website.endsWith(".org"))
        {
            System.out.println("it is an organisational website ");
        }
       else if(website.endsWith(".com"))
        {
            System.out.println("it is a commercial website ");
        }
        else if(website.endsWith(".in"))
        {
            System.out.println("it is an  INDIAN website ");
        }
        else {
            System.out.println("me dont know :(");
        }


    }
}
