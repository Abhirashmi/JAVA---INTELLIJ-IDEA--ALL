package com.company;

import java.util.Scanner;

public class tut6_cbseboard {
    public static void main(String[] args) {
        System.out.println("enter your name ");
        Scanner sc = new Scanner(System.in);
        String name=sc.nextLine();
        System.out.println("the name entered is "+ name +"And Have a good day !!!!!!!!!");
    }
}
