package com.company;

interface bicycle{
   void applybreak(int decrement);
   void speed_UP(int increment);
}

class Avoncycle implements bicycle{
    int speed=9;
    public void blow_horn(int volume){
        System.out.println("peeeee peeeeee @ volume "+volume);
    }
    public void applybreak(int d){
        speed=speed-d;
        System.out.println("APPLYING BREAK!!!!!! and decreasing your speed by "+d);
        System.out.format(" and making your speed %d from %d   by decreasing  it  by  %d \n",speed-d,speed,d);

    }
    public void speed_UP(int i){
        speed=speed+i;
        System.out.println("SPEEDING UP  !!!!! and INCREASING your speed by "+i);
        System.out.format(" and making your speed %d from %d   by speeding it up by  %d \n",speed+i,speed,i);

    }
}

public class tut_52_interfaces {
    public static void main(String[] args) {
        Avoncycle a=new Avoncycle();
        a.blow_horn(44);
        a.applybreak(3);
        a.speed_UP(9);

    }
}
