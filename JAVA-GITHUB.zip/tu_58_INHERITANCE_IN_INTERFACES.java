package com.company;
interface sample{
    void meth1();
    void meth2();
}
interface sample1 extends sample{
    void meth3();
    void meth4();
}

class mysampleclass implements sample1{
    public void meth4(){
        System.out.println("method 4 hu vro !!!!!!");
        }

    public void meth3(){
        System.out.println("method 3 hu vro!!!!! ");
    }
    public void meth2(){
        System.out.println("method 2 hu vro !!!!");
    }
    public void meth1(){
        System.out.println("method 1 hu vro !!!!!!!!");
    }


}

//interface child_sample{
//    void meth1();
//    void meth2();
//    void meth3();
//    void meth4();
//}

public class tu_58_INHERITANCE_IN_INTERFACES {
    public static void main(String[] args) {
mysampleclass sc=new mysampleclass();
        System.out.println(" hy vro method calling vro :]");
sc.meth1();
sc.meth2();
sc.meth3();
sc.meth4();
    }
}
