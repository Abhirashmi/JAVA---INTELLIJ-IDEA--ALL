package com.company;
import  java.util.Scanner;
public class tut_13 {
    public static void main(String[] args) {
//        //String name=new String("abhirashmi");
//        String name="abhirashmi";
//        System.out.println( "hey ! my name is "+name);
//
//        int a=4;
//        float b=66.777f;
//        System.out.printf("the value of a is %d and the value of b is %f",a,b);

Scanner sc=new Scanner(System.in);
        String st=sc.nextLine();
        System.out.print(st);
    }
}
