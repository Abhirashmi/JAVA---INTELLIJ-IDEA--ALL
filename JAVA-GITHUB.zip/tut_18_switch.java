package com.company;
import java.util.Scanner;
public class tut_18_switch{
    public static void main(String[] args) {
int age;
        System.out.println("enter your age ");
Scanner sc=new Scanner(System.in);
age=sc.nextInt();
    }
}
