package com.company;
class base1{
    base1(){
        System.out.println("base class contructor huu maiiii");
    }
    private int x;

    int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
}
class derive1 extends base1{
    derive1(){
        System.out.println("derive  class contructor huu maiiii");
    }
    int y;

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}

public class tut_46_constructors_in_inheritance {
    public static void main(String[] args) {

    }
}
