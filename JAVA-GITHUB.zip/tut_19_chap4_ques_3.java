package com.company;

import java.util.Scanner;

public class tut_19_chap4_ques_3 {
    public static void main(String[] args) {
//        float tax=0;
//        float income=3.3f;
//        if(income<2.5){
//            income=income+0;
//        }
//        else if (income>2.5 && tax<5f){
//            tax=
//        }

        Scanner sc=new Scanner(System.in);
        System.out.println("enter  the number between 1 to 7 to get their corresponding days ");
        int num= sc.nextInt();
        switch (num) {
            case 1:
                System.out.println("ITS MONDAY :)");
                break;
            case 2:
                System.out.println("ITS TUESDAY :)");
                break;
            case 3:
                System.out.println("ITS WEDNESDAY :)");
                break;
            case 4:
                System.out.println("ITS THURSDAY:)");
                break;
            case 5:
                System.out.println("ITS FRIDAY :)");
                break;
            case 6:
                System.out.println("ITS SATURDAY :)");
                break;
            case 7:
                System.out.println("ITS SUNDAY:)");
                break;
            default:
                System.out.println("kindly enter the valid number  ");
        }

    }
}
