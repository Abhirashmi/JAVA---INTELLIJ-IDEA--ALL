package com.company;
class cellphone{
    long ph_number;
    String ph_name;
    String customer_name;
    public void set_phone_number(long n){
       ph_number=n;
    }
    public void get_phone_number(){
        System.out.println(" phone number : "+ph_number);
    }
    public void set_phone_name(String n){
        ph_name=n;
    }

    public void get_phone_name(){
        System.out.println(" phone name is :"+ph_name);
    }

    public void calling(String n){
        customer_name=n;
        System.out.println(" TRING TRING ..................... CALLING "+customer_name);
    }

    public void vibrating(String n){
        customer_name=n;
        System.out.println(" BUZZZZZZZZZZZZZZZZZZZZZZZZZZ.....................PHONE VIBRATING  "+n);
    }


    public void customer_name(String a) {
        customer_name=a;
        System.out.println("customer name "+a);
    }
}

public class tut_39_ps {
    public static void main(String[] args) {
        cellphone realme=new cellphone();
//         realme.customer_name="ABHIRASHMI KUMARI ";
//        realme.ph_number=6204542388;

        realme.set_phone_number(62045488);
        realme.get_phone_number();
        realme.set_phone_name("REALME 6 PRO ");
        realme.get_phone_name();
        realme.calling("abhirashmi");
        realme.vibrating("rashmiiii");
        realme.calling("MUMMY");
        realme.customer_name("abhi");


    }
}
/*


package com.company;

class Employee{
    int salary;
    String name;

    public int getSalary(){
        return salary;
    }
    public String getName(){
        return name;
    }
    public void setName(String n){
        name = n;
    }
}

class CellPhone{
    public void ring(){
        System.out.println("Ringing...");
    }
    public void vibrate(){
        System.out.println("Vibrating...");
    }
    public void callFriend(){
        System.out.println("Calling Mukul...");
    }

}

class Square{
    int side;
    public int area(){
        return side*side;
    }
    public int perimeter(){
        return 4*side;
    }
}

class Tommy{
    public void hit(){
        System.out.println("Hitting the enemy");
    }
    public void run(){
        System.out.println("Running from the enemy");
    }
    public void fire(){
        System.out.println("Firing on the enemy");
    }
}
public class cwh_39_ch8ps {
    public static void main(String[] args) {
        /*
        // Problem 1
        Employee harry = new Employee();
        harry.setName("CodeWithHarry");
        harry.salary = 233;
        System.out.println(harry.getSalary());
        System.out.println(harry.getName());

        // Problem 2
        CellPhone asus = new CellPhone();
        asus.callFriend();
        asus.vibrate();
        //asus.ring();


        // Problem 3
        Square sq = new Square();
        sq.side = 3;
        System.out.println(sq.area());
        System.out.println(sq.perimeter());
         */

    // Problem 5
    /*Tommy player1 = new Tommy();
        player1.fire();
                player1.run();
                player1.hit();


                }
                }
 */