package com.company;

public class tut_34_RECURSION {
    static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }
        static int factorial_iterative(int n){
            if(n==0 || n==1){
                return 1;
            }
            else {
                int product=1;
                for(int i=1;i<=n;i++){
                  product=product*i;
                }
                return product;
            }
    }

    public static void main(String[] args) {

        System.out.println("The factorial of 7 is = "+ factorial(7));
        System.out.println("The factorial of 5 is = "+ factorial(5));

        System.out.println("using iterative method ");


        System.out.println("The factorial of 5 is = "+ factorial_iterative(7));
        System.out.println("The factorial of 5 is = "+ factorial_iterative(5));


    }
}


