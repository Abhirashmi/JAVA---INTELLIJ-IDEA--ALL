package com.company;

public class tut_24_break_continue {
    public static void main(String[] args) {
        for (int i=0;i<=50;i++){
            System.out.println(i);
            System.out.println("java is my 3rd programming language :)");
            if(i==5){
                System.out.println("breaking the looop ");
                break;
            }
        }
    }
}
