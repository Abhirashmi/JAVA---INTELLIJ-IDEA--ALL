package com.company;

public class tut_15_practice_set {
    public static void main(String[] args) {
        String line=" hey <|name|>, good morning !!!!!!";
       line= line.replace("<|name|>","abhirashmi kumari");
        System.out.println(line);
    }
}
