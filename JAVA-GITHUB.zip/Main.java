package com.company;

public class Main {

    public static void main(String[] args) {
	System.out.println("hello world");

	int num_1=5;
	int num_2=557;
	int num_3=78;
        System.out.println("sum= \n ");
	int sum=num_1+num_2+num_3;
	System.out.println(sum);

	System.out.println(" oh yes abhi so happy to write my first JAVA PROGRAM!!!!!!!!!!!!!!!!!!!:)\n");
    }
}
