package com.company;

public class tut_14_string_method {
    public static void main(String[] args) {
        String name="abhirashmi kumari     ";
        System.out.println(name);
        System.out.println(name.toLowerCase());
        System.out.println(name.toUpperCase());

        System.out.println(name.length());

        System.out.println(name.trim());

        System.out.println(name.substring(3));
        System.out.println(name.substring(0));
        System.out.println(name.substring(2,9));

        System.out.println(name.replace('r','t'));
        System.out.println(name.replace("abhi","my name was "));

        System.out.println(name.startsWith("ab"));

        System.out.println(name.endsWith("i"));

        System.out.println(name.endsWith("p"));
        System.out.println(name.charAt(8));

        System.out.println(name.indexOf('a'));//returns only the first substring
        System.out.println(name.indexOf('m'));
        System.out.println(name.equals("abhi"));

    }
}
