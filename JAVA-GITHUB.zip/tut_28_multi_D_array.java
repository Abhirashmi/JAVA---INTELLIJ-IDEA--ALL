package com.company;

public class tut_28_multi_D_array {
    public static void main(String[] args) {
        // int [] marks; 1 d array
        int [][] flats;
        flats=new int[2][3];
        flats[0][0]=101;
        flats[0][1]=102;
        flats[0][2]=103;
        flats[1][0]=201;
        flats[1][1]=202;
        flats[1][2]=203;
        int i,j=0;
        for (i=0;i<2;i++) {
            for (j=0;j<=2;j++) {
                System.out.println( " flats : " + "[" + i +  " ]"+ "[" + j + " ] "+ "  =  " + flats[i][j]);
            }
        }

    }
}
