package com.company;

public class tut_59_POLYMORPHISM_IN_INHERITANCE {
    public static void main(String[] args) {
        
    }
}
