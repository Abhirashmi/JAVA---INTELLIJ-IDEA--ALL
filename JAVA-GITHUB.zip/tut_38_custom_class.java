package com.company;
class employee{
    int id;
    int sal;
    String name;
 public void printdetails (){
     System.out.println(" my id is :"+id);
     System.out.println(" my salary is :"+sal);
     System.out.println(" my name is :"+name);
    }
};

public class tut_38_custom_class {
    public static void main(String[] args) {
        System.out.println("This is our custom class ");
        employee abhi=new employee();//instatiatiang a new employee object
        abhi.id=33;
        abhi.sal=55000;
        abhi.name="Abhirashmi Kumari";
        employee a=new employee();
        a.id=77;
        a.sal=00;
        a.name="A";

        System.out.println("ABHI'S id ="+abhi.id);
        System.out.println(" ABHI's salary ="+abhi.sal);
        System.out.println(" ABHI's Full name  ="+abhi.name);
        System.out.println("using print details method  ");
        a.printdetails();
        abhi.printdetails();
    }
}
