package com.company;

public class tut_4_LITERALS {
    public static void main(String[] args) {
        byte age =20;//integer literal =34
        char ch='A';
        float f1=44.5f;
        double d1=77777777.9999999d;
        boolean a=true;
        String abhi="hey this is abhirashmi . I am a btech student at kiit \n";
        System.out.println(abhi);
        System.out.println(age);
        System.out.println(f1);System.out.println(ch);
        System.out.println(d1);
    }
}
