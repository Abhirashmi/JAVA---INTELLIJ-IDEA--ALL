package com.company;
class base{
    int x;

    public int getX() {
        System.out.println("the value is :"+x);
        return x;
    }

    public void setX(int x) {
        System.out.println("now i am setting x ");
        this.x = x;
    }

    base (){
        System.out.println("my base class constructor !!!!!!!");
    }

    base (int a){
        System.out.println("my base class overloaded  constructor !!!!!!! with value if a"+a);
    }

}
class derive extends base{
    int y;
//    derive(){
//        super(0);
//        System.out.println("derived class  constructor !!!!!!1");
//    }

    derive(int a,int b){
        super(a);
        System.out.println("derived class  constructor !!!!!! is here with value of y "+b);
    }

    public int getY() {
        System.out.println("the value is :"+y);
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}

public class tut_45_inheritance {
    public static void main(String[] args) {
        base b=new base();
        b.setX(6);
        System.out.println(b.getX());
        derive d=new derive(4,9);
        d.setX(66);
        d.getX();
        d.setY(99);
        System.out.println(d.getX());
        d.getX();




    }
}
