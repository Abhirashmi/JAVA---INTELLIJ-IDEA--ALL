package com.company;

public class tut_51_library_implementation {
    public static void main(String[] args) {
        //online library having methods isssu,return,fine,
        //arrray to store the available books
        //arrray to store the isssued books
        //english books
        //fictions
        //hindi
        //biography
        //class wise book
        //add book
        //add magzine
        //etc..........
    }
}
