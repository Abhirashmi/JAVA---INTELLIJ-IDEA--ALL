package com.company;

class library{
    String[] books;
    int no_of_books;

    library(){
        this.books=new String[100];
        this.no_of_books=0;
    }

    void addbook(String book){
        this.books[no_of_books]=book;
        no_of_books++;
        System.out.println("A book named "+book+"  has been added to your library successfully at serial number "+no_of_books);

    }

    void showavailable_books(){
        System.out.println("AVAILABLE BOOKS ARE :- ");
        for (String book : this.books) {
    if(book==null){
    continue;
        }
            System.out.println("* "+book);
        }
    }
    void issuebook(String book){
        for (int i=0;i<this.books.length;i++) {
            if (this.books[i] == book) {
                System.out.println(" sorry !!!!!! ;( this book has been already isssued ");
                this.books[i] = null;
                return;
            }
        }
                System.out.println("SORRY "+book+" doesn't exist in our library !!!");
            }

            void  returnbook(String book){
        addbook(book);
            }
}

public class ut_61_library {
    public static void main(String[] args) {
library cl=new library();
cl.addbook("c");
cl.addbook("c++");
cl.addbook("data structure and algorithms ");
cl.addbook("java ");
cl.addbook("computer networks");
cl.addbook("Basic of python");
cl.showavailable_books();
cl.issuebook(" c++");
cl.issuebook("Dbms");
cl.showavailable_books();
cl.returnbook("Dbms");
cl.returnbook("c++");
    }
}
