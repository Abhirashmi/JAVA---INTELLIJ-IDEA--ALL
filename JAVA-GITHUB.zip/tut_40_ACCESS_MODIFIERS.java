package com.company;

public class tut_40_ACCESS_MODIFIERS {
    public static void main(String[] args) {

    }
}
