package com.company;
abstract class parent{
    public parent(){
        System.out.println("constructor hu vro !!!!!!!!");
    }
    public void hello(){
        System.out.println("hello vro!");
    }

    abstract public void greet() ;
}

class child extends parent{

    @Override
    public void greet(){
        System.out.println("good morning ");
    }
}

public class tut_51_abstract_class {
    public static void main(String[] args) {

    }
}
