package com.company;
import java.util.Scanner;
public class tut_19_chap_4_practice_set {
    public static void main(String[] args) {
     byte m1,m2,m3;
     Scanner sc=new Scanner(System.in);
        System.out.println("enter your marks in physics ");
        m1=sc.nextByte();
        System.out.println("enter your marks in maths ");
        m2=sc.nextByte();
        System.out.println("enter your marks in chemistry ");
        m3=sc.nextByte();
        float avg=(m1+m2+m3)/3.0f;
        System.out.println("your overall percentage :"+avg);
        if(avg>=40 && m1>=33 && m2>=33 &&m3>=33 ){
            System.out.println("CONGRATS !!!!!!!!! . you have been promoted :)");
        }
        else {
            System.out.println("fill the form once again as you have not obtained the required criteria  of marks and hence not being promoted! ");
        }
    }
}
