package com.company;
import java.util.Scanner;
public class tut_12_prob3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter an integer value to check the condition");
        int a=sc.nextInt();
        System.out.println(a>10);

    }
}
