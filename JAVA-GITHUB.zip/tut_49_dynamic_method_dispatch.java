package com.company;

import static java.lang.System.*;

class phone {
    public void showtime() {
        System.out.println("APNA TIME AAEGAA!!!!!!!");
    }

    public void on() {
        System.out.println("turning phone on");
    }
}

   class Smartphone extends phone{
      @Override
      public void on(){
          System.out.println("turning smartphone on");
      }

      public void music(){
          System.out.println("turning music on");
      }
  }


public class tut_49_dynamic_method_dispatch {
    public static void main(String[] args) {
        Smartphone s=new Smartphone();
        s.music();
        s.on();
        phone p=new phone();
        p.on();
        p.showtime();
        phone p1=new Smartphone();
        p1.on();
        p1.showtime();
//        p1.music();//not allowed
        

    }
}
