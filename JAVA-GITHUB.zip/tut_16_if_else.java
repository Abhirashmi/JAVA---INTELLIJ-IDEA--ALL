package com.company;
public class tut_16_if_else {
    public static void main(String[] args) {
        int a=9;
        if (a>18)
        {
            System.out.println("yes you can drive ");
        }
        else {
            System.out.println("you cant drive ");
        }
    }
}
