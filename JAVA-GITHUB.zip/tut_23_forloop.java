package com.company;

import java.util.Scanner;

public class tut_23_forloop {
    public static void main(String[] args) {
//        for (int i=1;i<=10;i++){
//            System.out.println(i);
//        }
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number ");
        int num= sc.nextInt();
        for (int i=1;i<=num;i++){
            if(i%2==0){
//                System.out.println(i +" is even ");
            }
            else {
                System.out.println(i+" is odd ");
            }
        }

        System.out.println("first "+num+" numbers in reverse order ");

for (int i=num;i>0;i--){
    System.out.println(i);
}
    }
}
