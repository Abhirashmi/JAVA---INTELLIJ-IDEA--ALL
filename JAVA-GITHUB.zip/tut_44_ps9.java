package com.company;
class cylinder{
    private int radius;
    private int height;

    public int getRadius() {
        System.out.println("radius is :"+radius);
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public int getHeight() {
        System.out.println("height is "+ height);
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void calculate (){
        System.out.println("as we know that surface area A is :  A=2πrh+2πr2 , taking pi 3.14");
        double a=(2*3.14*radius*height+2*radius*3.14*14);
        System.out.println("2*3.14*"+radius+"*"+height+"+2*"+radius+"*3.14*14  = " + a);
        System.out.println("as we know that volume  V  is : V=πr2h , taking pi 3.14");
        double b= 3.14*radius*radius*height;
        System.out.println("3.14*"+radius+"*"+radius+"*"+height +"+ = "+b);

    }
}

public class tut_44_ps9 {
    public static void main(String[] args) {
        cylinder c=new cylinder();
        c.setRadius(7);
        c.setHeight(9);
        c.getHeight();
        c.getRadius();
        c.calculate();

    }
}
 