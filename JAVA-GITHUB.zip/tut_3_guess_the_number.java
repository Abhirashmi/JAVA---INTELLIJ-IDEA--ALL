package com.company;
import java.util.Random;
import java.util.Scanner;

class game {
    public int number;
    public int input_number;
    public int numberofguess=0;

    public int getNumberofguess() {
        return numberofguess;
    }

    public void setNumberofguess(int numberofguess) {
        this.numberofguess = numberofguess;
    }

    void guessednumber() {
        Random rand = new Random();
        this.number = rand.nextInt(100);
        System.out.println("the value of number guessed by computer maharaj within bound 100 is :"+number);
    }

    void takeuserinput() {
        System.out.println("GUESS THE NUMBER !!!!!!!!!");
        Scanner sc = new Scanner(System.in);
        input_number = sc.nextInt();

    }

    boolean iscorrectnumber(){
        numberofguess=numberofguess+1;
        if (input_number == number){
           // numberofguess=numberofguess+1;
            System.out.println(" YAAAAAAHOOOOOOO!!!!!!!!!!!!!!!!the number you have GUESSSESD IS TRUE !!!!");
            System.out.format("you have guessed it in %d \n attempts and the number was %d",numberofguess,number);
            return true;
        }
        else if (input_number < number) {
            System.out.println("too low :(");
        }
        else if (input_number > number) {
            System.out.println("too high :(");
        }
        else
            System.out.println("OOOOOPPPPSSSSSSSSSSSSSSS!!!!!!!!!the number you have GUESSSESD IS FALSE !!!!");
            return false;
        }
    }


public class tut_3_guess_the_number {
    public static void main(String[] args) {
game g=new game();
boolean b=false;
while (!b){
    g.takeuserinput();
    b = g.iscorrectnumber();
    //System.out.println(b);
    System.out.println("lol ");
   // g.guessednumber();
}
    }
}
