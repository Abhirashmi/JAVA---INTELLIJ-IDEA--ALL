package com.company;

public class  tut9_associtivity {
    public static void main(String[] args) {
        
    }
}
