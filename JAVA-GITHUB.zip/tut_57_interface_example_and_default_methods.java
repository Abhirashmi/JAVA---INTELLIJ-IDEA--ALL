package com.company;
interface mycamera{
    void takesnap();
    void recordvideo(int n);
    private void flash(){
        System.out.println("flash on when night and flash off when day");
    }
    default void beautify(){
        flash();
        System.out.println("beautifying !!!!!! :)");
    }
}

class phone1{
    public void calling(int num){
        System.out.println("CALLING ...."+num);
    }
    public void pickup(){
        System.out.println("CONNECTING ");
    }

}

class smartphone1 extends phone1 implements mycamera{
    public void takesnap(){
        System.out.println("TAKING PICTURE.........CLICKKKKKK");
    };
    public void recordvideo(int n){
        System.out.println("RECORDING VIDEO in "+n+" megapixel ");
    };
}

public class tut_57_interface_example_and_default_methods {
    public static void main(String[] args) {
smartphone1 samsung=new smartphone1();
        System.out.println("your new phone samsung m31 can: ");
samsung.calling(333333388);
samsung.pickup();
samsung.recordvideo(444);
samsung.beautify();
samsung.takesnap();
//samsung.flash();

    }
}
