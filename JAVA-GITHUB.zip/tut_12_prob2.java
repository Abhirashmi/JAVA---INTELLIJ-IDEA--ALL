package com.company;

public class tut_12_prob2 {
    public static void main(String[] args) {
        char grade='A';
        grade=(char)(grade+8);
        System.out.println("my grade after addding 8 to the actual grade  .");
        System.out.println(grade);
        System.out.println("now decrypting my grade ");
        grade=(char) (grade-8);
        System.out.println(grade);

    }
}
