package com.company;

public class tut8_operators {
    public static void main(String[] args) {
        int a=5;
        int b=a+6;
        System.out.println(b);
        System.out.println(6==6);
        System.out.println(5==8);
    }
}
