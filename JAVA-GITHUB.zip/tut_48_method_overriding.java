package com.company;
class a{
 int a;
public void met1(){
    System.out.println("i am method 1 of a");
}

}

class b extends a{
    public void met2(){
        System.out.println("i am method 2  of b");
    }
    @Override
    public void met1(){
        System.out.println("i am method 1 of b");
    }
}

public class tut_48_method_overriding {
    public static void main(String[] args) {
        a a=new a();
        a.met1();
        b b=new b();
        b.met1();
        b.met2();




    }
}
