package com.company;

public class tut_32_METHOD_OVERLOADING {
    static void change (int a){
        a=99;
    }
    static void change1 (int []arr){
        arr[0]=99;
    }

    public static void main(String[] args) {
        int[] marks = {44, 99, 87, 67, 99};
        //changing the integer
//        int x=66;
//        change(8);
//        System.out.println("The value of x after changing is "+x);
//    }
//changing the array

        int[] marks1={44,89,87,67,99};
        change1(marks);
        System.out.println("the value of arr [0] after  running change 2 is :"+marks[0]);
    }
}

