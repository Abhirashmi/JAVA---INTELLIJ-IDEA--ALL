package com.company;

class my_main_employee{
    private  int id;
    private String name;
    private  int sal;

    public my_main_employee(){
        id=66;
        name="tinkuuuu jiyaaaa";
        sal=77000;
    }

    public void set_name(String n){
        name=n;
    }

    public void set_id(int n){
        id=n;
    }

    public void set_sal(int n){
        sal=n;
    }
    public void get_name(){
        System.out.println("name is "+name);
    }

    public void get_id(){
        System.out.println("id is "+id);
    }
    public void get_sal(){
        System.out.println("SALARY  is "+sal);
    }
}

public class tut_42_constructors___ {
    public static void main(String[] args) {
        my_main_employee abhi=new my_main_employee();
//        abhi.set_id(77);
//        abhi.set_name("abhirashmi kumari");
//        abhi.set_sal(99000);
//        abhi.get_id();
//        abhi.get_name();
        abhi.get_id();
        abhi.get_name();
        abhi.get_sal();

    }
}
